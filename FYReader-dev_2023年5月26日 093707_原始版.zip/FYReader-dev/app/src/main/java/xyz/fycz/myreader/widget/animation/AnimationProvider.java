/*
 * This file is part of FYReader.
 * FYReader is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * FYReader is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with FYReader.  If not, see <https://www.gnu.org/licenses/>.
 *
 * Copyright (C) 2020 - 2022 fengyuecanzhu
 */

package xyz.fycz.myreader.widget.animation;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PointF;
import android.widget.Scroller;

/**
 * Created by Administrator on 2016/8/1 0001.
 */
public abstract class AnimationProvider {

    public enum Direction {
        NONE(true),NEXT(true), PRE(true), UP(false), DOWN(false);

        public final boolean isHorizontal;

        Direction(boolean isHorizontal) {
            this.isHorizontal = isHorizontal;
        }
    }

    protected Bitmap mCurPageBitmap,mNextPageBitmap;
    protected float myStartX;
    protected float myStartY;
    protected int myEndX;
    protected int myEndY;
    protected Direction myDirection;

    protected int mScreenWidth;
    protected int mScreenHeight;

    protected PointF mTouch = new PointF(); // 拖拽点
    private Direction direction = Direction.NONE;
    private boolean isCancel = false;

    public AnimationProvider(int width,int height) {
        mCurPageBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        mNextPageBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);

        this.mScreenWidth = width;
        this.mScreenHeight = height;
    }

    //绘制滑动页面
    public abstract void drawMove(Canvas canvas);

    //绘制不滑动页面
    public abstract void drawStatic(Canvas canvas);

    //设置开始拖拽点
    public void setStartPoint(float x,float y){
        myStartX = x;
        myStartY = y;
    }

    //设置拖拽点
    public void setTouchPoint(float x,float y){
        mTouch.x = x;
        mTouch.y = y;
    }

    //设置方向
    public void setDirection(Direction direction){
        this.direction = direction;
    }

    public Direction getDirection(){
        return direction;
    }

    public void setCancel(boolean isCancel){
        this.isCancel = isCancel;
    }

    public abstract void startAnimation(Scroller scroller);

    /**
     * 转换页面，在显示下一章的时候，必须首先调用此方法
     */
    public void changePage(){
        Bitmap bitmap = mCurPageBitmap;
        mCurPageBitmap = mNextPageBitmap;
        mNextPageBitmap = bitmap;
    }

    public Bitmap getNextBitmap(){
        return mNextPageBitmap;
    }

    public Bitmap getBgBitmap(){
        return mNextPageBitmap;
    }

    public boolean getCancel(){
        return isCancel;
    }
}
